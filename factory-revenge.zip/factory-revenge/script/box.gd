extends CharacterBody2D

func push(direction: Vector2, speed: float):
	velocity = direction * speed
	move_and_slide()
