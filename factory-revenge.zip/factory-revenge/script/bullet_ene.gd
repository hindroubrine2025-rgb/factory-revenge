extends Area2D

@export var speed := 200.0

var direction := Vector2.ZERO

func _physics_process(delta):
	position += direction * speed * delta
	
	await get_tree().create_timer(0.75).timeout
	queue_free()

func _on_body_entered(body: Node2D):
	$AudioStreamPlayer2D.playing = true
	$Sprite2D.visible = false
	$PointLight2D.visible = false
	await get_tree().create_timer(0.1).timeout
	queue_free()
	
	if body.is_in_group("player"):
		get_tree().reload_current_scene()
