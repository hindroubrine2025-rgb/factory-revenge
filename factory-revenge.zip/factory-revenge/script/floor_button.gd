extends Area2D

enum Dir { UP, DOWN, LEFT, RIGHT }

@export var direction: Dir = Dir.UP
@export var big_bullet_scene: PackedScene  # الطلقة الكبيرة (نسخة أكبر من bullet.tscn)
@export var damage: int = 50
@export var cooldown: float = 1.0
@export var spawn_point: Marker2D  # وين تطلع منها الطلقة (اختياري)

var can_fire: bool = true

var dir_vectors := {
	Dir.UP: Vector2.DOWN,
	Dir.DOWN: Vector2.UP,
	Dir.LEFT: Vector2.RIGHT,
	Dir.RIGHT: Vector2.LEFT,
}


func _on_body_entered(body: Node2D) -> void:
	if body:
		$Sprite2D.frame = 1
		$click.playing = true
	
	if not can_fire:
		return
	if not body.is_in_group("player"):
		return

	fire()

func _on_body_exited(body: Node2D) -> void:
	if body:
		$Sprite2D.frame = 0
		$click2.playing = true


func fire() -> void:
	can_fire = false
	
	var bullet = big_bullet_scene.instantiate()
	var start_pos = spawn_point.global_position if spawn_point else global_position
	bullet.global_position = start_pos
	bullet.direction = dir_vectors[direction]
	bullet.damage = damage
	bullet.target_group = "boss"
	get_tree().current_scene.add_child(bullet)
	
	await get_tree().create_timer(cooldown).timeout
	can_fire = true
