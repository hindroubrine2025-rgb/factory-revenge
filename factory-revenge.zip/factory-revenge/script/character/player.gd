extends CharacterBody2D

@export var speed: float = 75.0

@export var dash_speed: float = 250.0
@export var dash_time: float = 0.15

@export var bullet_scene: PackedScene

var dash_direction: Vector2 = Vector2.ZERO
var is_dashing: bool = false

func _physics_process(_delta: float) -> void:
	if Input.is_action_just_pressed("dash") and !is_dashing:
		start_dash()
	if Input.is_action_just_pressed("shoot"):
		shoot()
		$shoot.playing = true
	
	
	var input = Input.get_vector("left", "right", "up", "down")
	
	if input.x > 0: $AnimatedSprite2D.flip_h = false
	elif input.x < 0: $AnimatedSprite2D.flip_h = true
	
	if is_dashing:
		velocity = dash_direction * dash_speed
	else:
		if input:
			velocity = input * speed
			if $AnimatedSprite2D.animation != "walk": $AnimatedSprite2D.animation = "walk"
		else:
			velocity = velocity.move_toward(Vector2.ZERO, speed)
			if $AnimatedSprite2D.animation != "idle": $AnimatedSprite2D.animation = "idle"
	
	move_and_slide()
	
	for i in range(get_slide_collision_count()):
		var collision = get_slide_collision(i)
		var body = collision.get_collider()

		if body.has_method("push"):
			body.push(velocity.normalized(), velocity.length())

func start_dash():
	var input = Input.get_vector("left", "right", "up", "down")
	
	if input == Vector2.ZERO:
		return
		
	
	dash_direction = input.normalized()
	is_dashing = true
	$dash.playing = true
	
	$GPUParticles2D.emitting = true
	
	await get_tree().create_timer(dash_time).timeout
	is_dashing = false


func shoot():
	var bullet = bullet_scene.instantiate()
	bullet.global_position = $ShootPoint.global_position
	
	bullet.direction = get_aim_direction()
	
	get_tree().current_scene.add_child(bullet)


func get_aim_direction() -> Vector2:

	# إذا لم يُستخدم، استخدم الماوس
	return (get_global_mouse_position() - global_position).normalized()



@export var max_health: int = 200
var health: int = max_health

var is_dead: bool = false


func take_damage(amount: int) -> void:
	if is_dead:
		return

	health -= amount
	health = max(health, 0)

	# وميض أبيض/أحمر لحظة الضرب
	modulate = Color(1, 0.3, 0.3)
	await get_tree().create_timer(0.1).timeout
	modulate = Color(1, 1, 1)

	if health <= 0:
		die()


func die() -> void:
	is_dead = true
	set_physics_process(false)

	if $Hitbox/CollisionShape2D:
		$Hitbox/CollisionShape2D.disabled = true

	$AnimatedSprite2D.animation = "die"
	await $AnimatedSprite2D.animation_finished

	queue_free()
