extends CharacterBody2D

@onready var player_node: CharacterBody2D = %player
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

@export var speed: float = 128.0

var should_chase: bool = false

func _physics_process(delta: float) -> void:
	if should_chase:
		var dir = (player_node.global_position - global_position).normalized()
		velocity = lerp(velocity, dir * speed, 0.5 * delta)
	else:
		velocity = Vector2.ZERO

	move_and_slide()

	# قلب السبرايت
	if velocity.x > 0:
		sprite.flip_h = false
	elif velocity.x < 0:
		sprite.flip_h = true

	# تشغيل الأنيميشن
	if velocity.length() > 5:
		sprite.play("walk")
	else:
		sprite.play("idle")

func _on_enter_area_body_entered(body: Node2D) -> void:
	if body == player_node:
		should_chase = true
		$AudioStreamPlayer2D.playing = true

func _on_exit_area_body_exited(body: Node2D) -> void:
	if body == player_node:
		should_chase = false

func _on_killing_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		get_tree().reload_current_scene()
