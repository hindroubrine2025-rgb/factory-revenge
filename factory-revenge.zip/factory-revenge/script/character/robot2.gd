extends CharacterBody2D

@onready var player_node: CharacterBody2D = %player
@onready var sprite: Sprite2D = $Sprite2D

@export var speed: float = 128.0

@export var bullet_scene: PackedScene

@onready var shoot_timer: Timer = $Timer

var should_chase: bool = false

func _physics_process(delta: float) -> void:
	if should_chase:
		var dir = (player_node.global_position - global_position).normalized()
		velocity = lerp(velocity, dir * speed, 0.5 * delta)
	else:
		velocity = Vector2.ZERO

	move_and_slide()

	# قلب السبرايت
	if velocity.x > 0:
		sprite.flip_h = false
	elif velocity.x < 0:
		sprite.flip_h = true

func _on_enter_area_body_entered(body):
	if body == player_node:
		should_chase = true
		shoot_timer.start()
		$AudioStreamPlayer2D.playing = true

func _on_exit_area_body_exited(body):
	if body == player_node:
		should_chase = false
		shoot_timer.stop()

func _on_killing_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		get_tree().reload_current_scene()

func _on_timer_timeout() -> void:
	if !should_chase:
		return

	var bullet = bullet_scene.instantiate()
	get_parent().add_child(bullet)

	bullet.global_position = global_position

	bullet.direction = (player_node.global_position - global_position).normalized()
