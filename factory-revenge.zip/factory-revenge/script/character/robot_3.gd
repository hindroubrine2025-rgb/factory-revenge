extends CharacterBody2D

@export var speed: float = 60.0

@export var dash_speed: float = 220.0
@export var dash_time: float = 0.2
@export var dash_cooldown: float = 1.5

@export var bullet_scene: PackedScene
@export var attack_range: float = 250.0
@export var attack_cooldown: float = 1.0
@export var attack_damage: int = 15
@export var dash_damage: int = 10

var player: Node2D
var dash_direction: Vector2 = Vector2.ZERO
var is_dashing: bool = false
var can_dash: bool = true
var can_attack: bool = true
var is_attacking: bool = false


var attack_choice_cooldown: bool = false


func _physics_process(_delta: float) -> void:
	if player == null:
		velocity = velocity.move_toward(Vector2.ZERO, speed)
		if $AnimatedSprite2D.animation != "idle": $AnimatedSprite2D.animation = "idle"
		move_and_slide()
		return

	if is_attacking or is_recovering:
		move_and_slide()
		return

	var dist = global_position.distance_to(player.global_position)

	if can_dash and can_attack and not attack_choice_cooldown:
		# لو الاثنين متاحين، اختار عشوائي بينهم بدل نمط ثابت
		attack_choice_cooldown = true
		if randf() < 0.5:
			start_dash()
		else:
			start_attack()
		await get_tree().create_timer(0.1).timeout
		attack_choice_cooldown = false
	elif can_dash and dist > attack_range:
		start_dash()
	elif can_attack:
		start_attack()

	if player.global_position.x > global_position.x:
		$AnimatedSprite2D.flip_h = false
	else:
		$AnimatedSprite2D.flip_h = true

	if is_dashing:
		velocity = dash_direction * dash_speed
	else:
		var dir = global_position.direction_to(player.global_position)
		velocity = dir * speed
		if $AnimatedSprite2D.animation != "walk": $AnimatedSprite2D.animation = "walk"

	move_and_slide()

	for i in range(get_slide_collision_count()):
		var collision = get_slide_collision(i)
		var body = collision.get_collider()
		if body and body.has_method("push"):
			body.push(velocity.normalized(), velocity.length())


var is_recovering: bool = false
@export var dash_recovery_time: float = 0.6


func start_dash() -> void:
	if player == null:
		return

	dash_direction = global_position.direction_to(player.global_position)
	is_dashing = true
	can_dash = false

	$AnimatedSprite2D.animation = "dash"
	$dash.playing = true
	$GPUParticles2D.emitting = true

	$Hitbox/CollisionShape2D.disabled = false

	await get_tree().create_timer(dash_time).timeout
	is_dashing = false
	$Hitbox/CollisionShape2D.disabled = true

	# فترة نقاهة يوقف فيها ويسوي idle
	is_recovering = true
	velocity = Vector2.ZERO
	$AnimatedSprite2D.animation = "idle"
	await get_tree().create_timer(dash_recovery_time).timeout
	is_recovering = false

	await get_tree().create_timer(dash_cooldown).timeout
	can_dash = true


func start_attack() -> void:
	is_attacking = true
	can_attack = false
	velocity = Vector2.ZERO

	$AnimatedSprite2D.animation = "attack"
	$attackSound.playing = true

	# ننتظر لحظة إطلاق الطلقة بالضبط (نص الأنيميشن تقريبًا)
	await get_tree().create_timer(0.25).timeout
	shoot()

	await get_tree().create_timer(0.3).timeout
	is_attacking = false

	await get_tree().create_timer(attack_cooldown).timeout
	can_attack = true


func shoot() -> void:
	if player == null or bullet_scene == null:
		return

	var bullet = bullet_scene.instantiate()
	bullet.global_position = global_position
	bullet.direction = global_position.direction_to(player.global_position)
	bullet.speed = 100.0
	
	get_tree().current_scene.add_child(bullet)


func enable_hitbox() -> void:
	$Hitbox/CollisionShape2D.disabled = false


func disable_hitbox() -> void:
	$Hitbox/CollisionShape2D.disabled = true


func _on_hitbox_body_entered(body: Node) -> void:
	if body.has_method("take_damage"):
		var dmg = dash_damage if is_dashing else attack_damage
		body.take_damage(dmg)


func set_target(new_player: Node2D) -> void:
	player = new_player


@export var max_health: int = 25
var health: int = max_health
var is_dead: bool = false

func take_damage(amount: int) -> void:
	if is_dead:
		return
	health -= amount
	if health <= 0:
		is_dead = true
		die()


func _on_killing_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		get_tree().reload_current_scene()


func die() -> void:
	print("DIE CALLED")
	is_dead = true
	set_physics_process(false)

	if $Hitbox/CollisionShape2D:
		$Hitbox/CollisionShape2D.disabled = true

	open_door()  # يفتح الباب فور الموت
	
	queue_free()




var door_to_open: Node2D = null
var coll_to_open: CollisionShape2D = null

func set_door_to_open(d: Node2D, c: CollisionShape2D) -> void:
	door_to_open = d
	coll_to_open = c

func open_door() -> void:
	print("door_to_open: ", door_to_open, " coll: ", coll_to_open)
	if coll_to_open:
		coll_to_open.set_deferred("disabled", true)
	if door_to_open:
		door_to_open.visible = false
