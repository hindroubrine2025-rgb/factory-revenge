extends Node2D

@export var door: StaticBody2D

func _on_area_2d_body_entered(body: Node2D) -> void:
	if body:
		$StaticBody2D/CollisionShape2D.set_deferred("disabled", true)
		$StaticBody2D/Sprite2D.visible = false

func _on_area_2d_body_exited(body: Node2D) -> void:
	if body:
		$StaticBody2D/CollisionShape2D.set_deferred("disabled", false)
		$StaticBody2D/Sprite2D.visible = true
