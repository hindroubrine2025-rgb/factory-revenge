extends Camera2D

@export var smooth_camera: bool = true

@onready var screen_sizes: Vector2 = get_viewport_rect().size
@onready var player_node = get_parent().get_node("player")

func _ready() -> void:
	set_screen_position()
	await get_tree().process_frame
	position_smoothing_enabled = smooth_camera
	position_smoothing_speed = 7.0

func _process(_delta: float) -> void:
	set_screen_position()

func set_screen_position():
	var player_pos = player_node.global_position
	var x = floor(player_pos.x / screen_sizes.x) * screen_sizes.x
	var y = floor(player_pos.y / screen_sizes.y) * screen_sizes.y
	global_position = Vector2(x, y)
