extends Area2D

@export var speed := 400.0
@export var damage: int = 2
var direction: Vector2 = Vector2.ZERO

func _ready() -> void:
	$GPUParticles2D.modulate = Color(3, 2, 1)
	await get_tree().create_timer(0.75).timeout
	queue_free()

func _physics_process(delta):
	position += direction * speed * delta

func _on_body_entered(body: Node2D):
	if body.is_in_group("enemy"):
		body.queue_free()
	if body.is_in_group("boss") and body.has_method("take_damage"):
		body.take_damage(damage)
	set_physics_process(false)
	$CollisionShape2D.set_deferred("disabled", true)
	$AudioStreamPlayer2D.playing = true
	$Sprite2D.visible = false
	$PointLight2D.visible = false
	await get_tree().create_timer(0.1).timeout
	queue_free()
