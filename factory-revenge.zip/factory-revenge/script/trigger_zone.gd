extends Area2D

@export var boss_scene: PackedScene
@export var boss_spawn_point: Marker2D
@export var door: Node2D  # الباب اللي بيتقفل
@export var door2: Node2D
@export var coll_door: CollisionShape2D  # الباب اللي بيتقفل
@export var coll_door2: CollisionShape2D

var triggered: bool = false

func _on_body_entered(body: Node2D) -> void:
	if triggered:
		return
	if not body.is_in_group("player"):
		return

	triggered = true
	
	lock_door()
	spawn_boss()
	queue_free()  # ما نحتاجها بعدين، تتصادم مرة وحدة بس


func lock_door() -> void:
	if coll_door and coll_door2:
		coll_door.set_deferred("disabled", false)
		door.visible = true
		coll_door2.set_deferred("disabled", false)
		door2.visible = true


func spawn_boss() -> void:
	call_deferred("_do_spawn_boss")


func _do_spawn_boss() -> void:
	var boss = boss_scene.instantiate()
	boss.global_position = boss_spawn_point.global_position
	get_tree().current_scene.add_child(boss)
	boss.set_target(get_tree().get_first_node_in_group("player"))
	boss.set_door_to_open(door2, coll_door2)
