extends Area2D



func _on_body_entered(body: Node2D) -> void:
	if body:
		$Sprite2D.frame = 1
		$click.playing = true

func _on_body_exited(body: Node2D) -> void:
	if body:
		$Sprite2D.frame = 0
		$click2.playing = true
